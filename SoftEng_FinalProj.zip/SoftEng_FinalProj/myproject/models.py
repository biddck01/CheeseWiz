# myproject/models.py
from django.db import models

class Cheese(models.Model):
    name = models.CharField(max_length=255)
    milk = models.CharField(max_length=255)
    country = models.CharField(max_length=255)
    region = models.CharField(max_length=255)
    family = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    texture = models.CharField(max_length=255)
    rind = models.CharField(max_length=255)
    flavor = models.CharField(max_length=255)
    aroma = models.CharField(max_length=255)
    vegetarian = models.BooleanField()
    vegan = models.BooleanField()