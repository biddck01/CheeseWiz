# utils.py
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer

# Global variable for the dataset
df = None

# Load dataset
def load_dataset():
    global df  # Declare df as global
    df = pd.read_csv("cheeses.csv")
    return df

# Preprocess dataset for feature extraction
def preprocess_data():
    global df  # Declare df as global
    if df is None:
        df = load_dataset()
    
    attributes_to_process = [
        'milk', 'country', 'region', 'family', 'type', 
        'texture', 'rind', 'color', 'flavor', 'aroma'
    ] 

    # Fill missing values or 'NA' with 'Unknown' for all attributes
    for attr in attributes_to_process:
        df[attr] = df[attr].replace(['NA', ''], 'Unknown').fillna('Unknown')

    # Convert boolean columns to string for concatenation
    df['vegetarian'] = df['vegetarian'].astype(str)
    df['vegan'] = df['vegan'].astype(str)

    # Combine important features into a single 'features' column
    df['features'] = df[attributes_to_process].apply(lambda row: ' '.join(row.values), axis=1)
    df['features'] += ' ' + df['vegetarian'] + ' ' + df['vegan']  # Optionally include 'vegetarian' and 'vegan'
    
    return df

# Initialize TF-IDF vectorizer and compute cosine similarity
def compute_cosine_similarity():
    global df  # Declare df as global
    if df is None:
        df = load_dataset()
    
    tfidf = TfidfVectorizer()
    tfidf_matrix = tfidf.fit_transform(df['features'])
    cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)
    return tfidf, cosine_sim, tfidf_matrix

# Recommend cheeses based on user preferences
def recommend_based_on_preferences(preferences):
    global df  # Declare df as global
    if df is None:
        df = load_dataset()
    
    user_pref_list = [value for key, value in preferences.items() if value != 'N/A']
    user_preferences = ' '.join(user_pref_list)

    # Call compute_cosine_similarity() to get tfidf and cosine_sim
    tfidf, cosine_sim, tfidf_matrix = compute_cosine_similarity()

    # Transform user preferences into TF-IDF space
    user_tfidf = tfidf.transform([user_preferences])
    sim_scores = cosine_similarity(user_tfidf, tfidf_matrix)
    
    # Enumerate similarities
    sim_scores = list(enumerate(sim_scores[0]))
    sim_indices = [i[0] for i in sim_scores]  # All indices
    
    # Compute the number of matching attributes
    recommendations = []
    for sim_idx in sim_indices:
        cheese_name = df['cheese'].iloc[sim_idx]
        shared_attributes = [
            f"{attr}: {df.iloc[sim_idx][attr]}" 
            for attr, value in preferences.items() 
            if value != 'N/A' and value in df.iloc[sim_idx][attr]
        ]
        # Only consider cheeses that match at least one attribute
        if shared_attributes:
            recommendations.append((cheese_name, shared_attributes))
    
    # Sort by the number of shared attributes (descending), then by cosine similarity
    recommendations = sorted(recommendations, key=lambda x: (-len(x[1]), sim_scores[df.index[df['cheese'] == x[0]].tolist()[0]][1]))

    # Return the top 5 recommendations
    return recommendations[:5]

# Group cheeses by a specific attribute type
def group_cheeses_by_attribute(attribute):
    global df  # Declare df as global
    if df is None:
        df = load_dataset()
    
    if attribute not in df.columns:
        return f"Attribute '{attribute}' not found in the dataset."

    grouped_cheeses = {}
    
    for _, row in df.iterrows():
        # Multi-value attributes are stored in quotes, split while respecting quotes
        attribute_values = [value.strip() for value in row[attribute].split(', ') if value != 'Unknown']
        for value in attribute_values:
            if value not in grouped_cheeses:
                grouped_cheeses[value] = []
            grouped_cheeses[value].append(row['cheese'])
    
    # Sort the cheeses in each group for better readability
    for group in grouped_cheeses:
        grouped_cheeses[group] = sorted(grouped_cheeses[group])
    
    return grouped_cheeses