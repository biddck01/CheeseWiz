# myproject/api_views.py
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from .models import Cheese
from .serializers import CheeseSerializer
from .utils import recommend_based_on_preferences, group_cheeses_by_attribute

class CheeseRecommendationView(APIView):
    def post(self, request):
        preferences = request.data
        recommendations = recommend_based_on_preferences(preferences)
        return Response(recommendations)

class CheeseGroupingView(APIView):
    def post(self, request):
        attribute_type = request.data['attribute_type']
        grouped_cheeses = group_cheeses_by_attribute(attribute_type)
        return Response(grouped_cheeses)