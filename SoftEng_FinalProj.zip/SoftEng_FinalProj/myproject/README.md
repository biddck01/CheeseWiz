For developer use:

Ensure python is installed using "python --version" in terminal. If it is not installed, install it from the Microsoft Store, then restart VSCode.
Run in the terminal: "pip install pandas scikit-learn".
Install the python extension for VSCode.
(optional) install Rainbow CSV extension for VSCode to color-code dataset.
